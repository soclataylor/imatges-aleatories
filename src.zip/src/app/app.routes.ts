import { Routes } from '@angular/router';
import { AfegirImatge } from './pages/afegir-imatge/afegir-imatge';

export const routes: Routes = [
    { path: 'afegir', component: AfegirImatge }, //Ruta bàsica
];
